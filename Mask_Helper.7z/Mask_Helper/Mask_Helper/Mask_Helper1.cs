﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mask_Helper
{
    public partial class Mask_Helper1 : Form
    {
        public Mask_Helper1()
        {
            InitializeComponent();
        }

        public void Form1_Load(object sender, EventArgs e)
        {

        }

        int m_PosX = 1;
        int m_PosY = 1;
        int m_X_Size = 1;
        int m_Y_Size = 1;

        public void textBox1_TextChanged(object sender, EventArgs e)
        {
            m_PosX = Convert.ToInt32(this.textBox1.Text.ToString());
            textBox1.Multiline = false;
            if (Int32.TryParse(textBox1.Text, out m_PosX))
            {
                //parse was successful
            }
            else
            {
                MessageBox.Show("Input string cannot be parsed to an integer");
            }
        }

        public void textBox2_TextChanged(object sender, EventArgs e)
        {
            m_PosY = Convert.ToInt32(this.textBox2.Text.ToString());
            textBox2.Multiline = false;
            if (Int32.TryParse(textBox2.Text, out m_PosY))
            {
                //parse was successful
            }
            else
            {
                MessageBox.Show("Input string cannot be parsed to an integer");
            }
        }

        public void textBox3_TextChanged(object sender, EventArgs e)
        {
            m_X_Size = Convert.ToInt32(this.textBox3.Text.ToString());
            textBox3.Multiline = false;
            if (Int32.TryParse(textBox3.Text, out m_X_Size))
            {
                //parse was successful
            }
            else
            {
                MessageBox.Show("Input string cannot be parsed to an integer");
            }
        }

        public void textBox4_TextChanged(object sender, EventArgs e)
        {
            m_Y_Size = Convert.ToInt32(this.textBox4.Text.ToString());
            textBox4.Multiline = false;
            if (Int32.TryParse(textBox4.Text, out m_Y_Size))
            {
                //parse was successful
            }
            else
            {
                MessageBox.Show("Input string cannot be parsed to an integer");
            }
        }

        public void button1_Click(object sender, EventArgs e)//create mask
        {
            Bitmap bmp = new Bitmap(pictureBox1.Image);
            Graphics gr = Graphics.FromImage(bmp);
            Pen p = new Pen(Color.White);
            System.Drawing.SolidBrush myBrush = new System.Drawing.SolidBrush(System.Drawing.Color.White);
            p.Width = 5.0f;

            Rectangle myRectangle = new Rectangle(m_PosX, m_PosY, m_X_Size, m_Y_Size);

            gr.DrawRectangle(p, m_PosX, m_PosY, m_X_Size, m_Y_Size);
            gr.FillRectangle(myBrush, new Rectangle(m_PosX, m_PosY, m_X_Size, m_Y_Size));
            pictureBox1.Image = bmp;
        }

        public void button2_Click(object sender, EventArgs e)//save modified image
        {
            SaveFileDialog save = new SaveFileDialog();
            if (save.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                System.IO.FileInfo fileinfo = new System.IO.FileInfo(save.FileName);
                switch (fileinfo.Extension.ToLower())
                {
                    case ".bmp":
                        pictureBox1.Image.Save(save.FileName, System.Drawing.Imaging.ImageFormat.Bmp);
                        break;
                    case ".png":
                        pictureBox1.Image.Save(save.FileName, System.Drawing.Imaging.ImageFormat.Png);
                        break;
                    case ".jpg":
                    case ".jpeg":
                        pictureBox1.Image.Save(save.FileName, System.Drawing.Imaging.ImageFormat.Jpeg);
                        break;
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)//exit application
        {
            this.Close();
        }

        public void button4_Click(object sender, EventArgs e)//Clear mask to redraw for LL
        {
            System.Diagnostics.Process.Start(Application.ExecutablePath); // to start new instance of application
            this.Close(); //to turn off current app
        }

        public void button5_Click(object sender, EventArgs e)//go to HL form
        {
            this.Hide();
            Mask_Helper1 f2 = new Mask_Helper1();
            f2.ShowDialog();
        }

        private void button6_Click(object sender, EventArgs e)//Go to LL form back
        {
           // this.Hide();
            //Form1 f1 = new Form1();
            //f1.ShowDialog();
        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Form1 f1 = new Form1();
            f1.ShowDialog();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Hide();
            Mask_Helper1 f2 = new Mask_Helper1();
            f2.ShowDialog();
        }
    }
}
